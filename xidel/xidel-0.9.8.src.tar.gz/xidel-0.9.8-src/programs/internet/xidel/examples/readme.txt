This directory contains large examples like bots.

For single line examples see the webpage