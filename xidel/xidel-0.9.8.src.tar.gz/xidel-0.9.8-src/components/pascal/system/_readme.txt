==============================================================================
  English:
==============================================================================
This is a command line parser for Delphi and FreePascal.
The licence is GPL, so if you use it, your program must also be licenced under
the GPL. (perhaps I will change it sometimes to a less restrictive licence).
Before parsing you have to create a TCommandLineReader object and tell it
the possible parameters with name, type, description, and default value.
Then you can read the parameters by name and with the first read the command
line options are parsed and stored in an internal cache.
When you read some later, the value is taken out of this cache.
If the command line contains invalid parameters a list of valid parameters
with the specified help information is automatically shown to the user.
However you can call it with "nameless parameters" if you use a parameter
without slash.
Look for examples in the source.

(Field) Properties:
    onShowError          TCommandLineReaderShowError   invalid parameter handle method
    automaticalShowError boolean;                      is the unit allowed to call the user
    allowDOSStyle        boolean;                      are DOS-style parameters allowed (/something)

Procedures: (see source for declare examples)
    parse()
      parses the command line options (you don't need to call this, it is
      automatically called by the first read called)
    parse(s:string)
      parses the options in s.
      Use this, if you don't want to read the command line, but something else.

    declareFlag(name,description:string;flagNameAbbreviation:char;default:boolean=false);
    declareFlag(name,description:string;default:boolean=false);
      declares a boolean flag. Using the name in cmdline inverts the default-value.
      Using --enable-name or --disable-name sets the value.
      You can write a list of flags, e.g. "-xyz", to set the flags with the abbreviation
      x, y and z.

    declareFile(name,description:string;default:string='');
      declares a use of an existing file.
      This allows lazy calling, e.g.   /file C:\strange\ - - \name
      is a valid parameter if you want to specify the file "C:\strange\ - - \name".
      The class merges the options until it finds an existing file, so be careful, because
      "/file C:\not existing\abc /create-it" will raise an error, because it tries to
      open "C:\not existing\abc /create-it".
      For such cases use a string parameter, e.g. /new-file "C:\not existing\abc".

    declareString(const name,description:string;value: string='');
    declareInt(const name,description:string;value: longint=0);
    declareFloat(const name,description:string;value: extended=0);
      declares a parameter with the obvious type.


Functions:
    function avaibleOptions():string;
      returns a list of possible parameters (for user information)

    function readString(const name:string):string;
    function readInt(const name:string):longint;
    function readFloat(const name:string):extended;
    function readFlag(const name:string):boolean;
      reads the declared parameter with the name.
      They will raise an error, if the paramter is not declared.
      If the parameter isn't in the cmdline, they return the
      default value.

      You can call readString with any parameter type (use it for files),
      but you can not call the others for a string parameter.

    function existsProperty(const name:string):boolean;
      Tests if the parameter name is declared.

    function readNamelessFiles():TStringArray; //not really implemented yet
    function readNamelessString():TStringArray;
    function readNamelessInt():TLongintArray;
    function readNamelessFloat():TFloatArray;
    function readNamelessFlag():TBooleanArray;
      get a list of parameters without an slash before them.


==============================================================================
  German/Deutsch:
==============================================================================
Dies ist ein Kommandozeilenparser f�r Delphi usnd FreePascal.
Der Quellcode ist unter der GPL lizenziert, so wenn man ihn verwendet, muss das 
ihn verwendende Programm auch unter der GPL stehen. (vielleicht �ndere ich die 
Lizenz mal zu einer mit weniger Beschr�nkungen).
Um ihn zu benutzen, muss man zuerst ein TCommandLineReader-Objekt erzeugen
und die verwendeten Parameter mit Angabe von Name, Typ, Beschreibung und
Standardwert deklarieren.
Dann kann man die Parameter anhand ihres Namens auslesen. Beim ersten Lesen
werden die Kommandozeilenparameter gelesen und in einem Array gespeichert.
Sp�ter Leseversuche erfolgen nur noch aus diesem Array.
Falsche Parameter f�hren zu einem Fehler und der Anzeige einer Liste mit allen
korrekten.
Man kann aber trotzdem namenlose Parameter verwenden, indem man nur den
Wert in der Kommandozeile angibt (wichtig: keinen Slash dabei verwenden).
Im Quellcode kann man Beispiele f�r die Verwendung finden.

Eigenschaften:
    onShowError          TCommandLineReaderShowError   Methode zur Anzeige der Parameterlist
    automaticalShowError boolean;                      Darf die Klasse dem Benutzer die Liste anzeigen
    allowDOSStyle        boolean;                      DOS-Style-Parameter erlauben (/something)

Procedures: (see source for declare examples)
    parse()
      Parst die Kommandozeile (wird automatisch beim ersten Leseaufruf gestartet)
    parse(s:string)
      Parst den String in s.

    declareFlag(name,description:string;flagNameAbbreviation:char;default:boolean=false);
    declareFlag(name,description:string;default:boolean=false);
      Definiert ein boolean-Flag. Gibt man nur den Namen in der Kommandozeile an, wird der
      Standardwert invertiert. Man kann aber auch --enable-name or --disable-name angeben, um den Wert explizit zu
      setzten.       
      Weiterhin kann man, z.B.: "-xyz", schreiben, um die Flags mit den Abk�rzungen (abbreviation)
      x, y und z zu invertieren.

    declareFile(name,description:string;default:string='');
      Definiert die Angabe eines exisitierenden(!) Dateinamens.
      Damit kann man die G�nsef��schen weglassen, z.B.: /file C:\strange\ - - \name
      kann angegeben werden, wenn die Datei "C:\strange\ - - \name" existiert.
      Der Name wird ermittelt, indem solange Stringteile aneinander geh�ngt werden, bis
      eine existierende Datei gefunden wird.
      Also wird "/file C:\not existing\abc /create-it" einen Fehler erzeugen, weil es die
      Datei "C:\not existing\abc /create-it" sucht.
      F�r sowas kann man einen Stringparameter /new-file="C:\not existing\abc /create-it" 
      benutzen.

    declareString(const name,description:string;value: string='');
    declareInt(const name,description:string;value: longint=0);
    declareFloat(const name,description:string;value: extended=0);
      Definiert einen Parameter mit dem zu erwartenden Verhalten.


Funktionen:
    avaibleOptions():string   listet die Parameter auf (um den Benutzer die Liste zu zeigen)

    function readString(const name:string):string;
    function readInt(const name:string):longint;
    function readFloat(const name:string):extended;
    function readFlag(const name:string):boolean;
      liest den Wert eines definierten Parameters.
      Wenn der Parameter nicht definiert wird, wird ein Fehler ausgel�st, wenn
      der Parameter nicht angegeben wurde, wird der Standardwert zur�ckgegeben.

      ReadString kann f�r das Lesen von beliebigen Parametertypen verwendet werden
      (insbesondere f�r Dateien), umgekehrt geht es aber nicht.

    function existsProperty(const name:string):boolean;
      Gibt an, ob die Eigenschaft definiert wurde.

    function readNamelessFiles():TStringArray; //not really implemented yet
    function readNamelessString():TStringArray;
    function readNamelessInt():TLongintArray;
    function readNamelessFloat():TFloatArray;
    function readNamelessFlag():TBooleanArray;
      Listet alle Parameter auf, die keinen Slash enthalten.
      

Benito van der Zander/BeniBela
benito@benibela.de
http://www.benibela.de